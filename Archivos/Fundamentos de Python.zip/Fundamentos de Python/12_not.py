print(not True)
print(not False)

print("NOT AND")
print("True AND True => ", not (True and True))
print("True AND False => ", not (True and False))
print("False AND False => ", not (False and False))

stock = input("Ingrese el numero de stock => ")
stock = int(stock)
print(not(stock >= 100 and stock <= 1000))
