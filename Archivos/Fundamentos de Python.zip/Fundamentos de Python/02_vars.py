print("Hola vars soy alex.")
# Es una variable de nombre
mi_nombre = "Alex"
print(mi_nombre)
#Es una variable de numero
mi_edad = 28
print(mi_edad)
mi_edad = 32
print("aqui cambio la edad", mi_edad)
# input
mi_nombre = input("¿Cual es tu nombre?")
print("usando input", mi_nombre)
mi_edad = input("¿Cual es tu edad?")
print("inpunt", mi_edad)
