# string cadenas de texto
mi_nombre = "Alex"
mi_nombre = 'Alex'
print("mi_nombre =>", mi_nombre)
print(type(mi_nombre))
#int enteros
mi_edad = 28
print("mi_edad =>", mi_edad)
print(type(mi_edad))
#boolean falso o verdadero
estado_civil = True
print("estado_civil =>", estado_civil)
print(type(estado_civil))
#inputs para agregar el valor
mi_edad = input("¿Cual es tu edad?")
print("mi_edad =>", mi_edad)
print(type(mi_edad))
