nombre = "alex"
print(type(nombre))
nombre = 28
print(type(nombre))
nombre = True
print(type(nombre))

print("Alex" + " Jose")
print(32 - 28 )
print("28" + "Alex")

edad = 28
print("Mi edad es " + str(edad))
print(f"Mi edad es {edad}")

edad = input("Cual es tu edad => ") 
print(type(edad))
edad = int(edad)
edad += 10
print(f"La edad 10 años despues {edad}")

name = 'Juana'
print(name)
age = '10'
print(age)
total = int(age) + 10

ten = f"Hola mi nombre es {name}, tengo {age} años y en 10 años tendré {total} años"
print(ten)