# CRUD Create, Read, Update & Delete
numeros = [1,2,3,4,5]
print(numeros[1])
numeros[-1] = 10
print(numeros)

numeros.append(336)
print(numeros)

numeros.insert(0, "Alex")
print(numeros)

numeros.insert(3, "Jose")
print(numeros)

tareas = ["correr","ejercicio","leer"]
nueva_lista = numeros + tareas
print(nueva_lista)

print(nueva_lista.index("correr"))
indice = nueva_lista.index("correr")
nueva_lista[indice] = "caminar"
print(nueva_lista)

nueva_lista.remove("Jose")
print(nueva_lista)

nueva_lista.pop()
print(nueva_lista)

nueva_lista.pop(1)
print(nueva_lista)

nueva_lista.reverse()
print(nueva_lista)

numeros1 = [5,7,9,1,4,3,6,2,8]
numeros1.sort()
print(numeros1)

cadena = ["Alex","Carlos","Dayana","Barbara"]
cadena.sort()
print(cadena)