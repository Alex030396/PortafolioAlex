"""
print("Hola esto es python")
print("Hola soy Alex y tengo 28 años")
print(10+9)
print(10-5)
print(5*2)
print(8/2)
## El comentario legendario.
"""
"""
Para hacer un escrito largo.
Que pueda volver a utilizar y ver
Para saber que estoy haciendo. 
Porque soy el mejor programador de Python.
"""
import random

opciones = ("pieda","tijera","papel")

computadora_gana = 0
usuario_gana = 0
rounds = 1

while True:
  print('+'*10)
  print('ROUND',rounds)
  print('+'*10)
  print('Computadora gana =',computadora_gana)
  print('Computadora usuario =',usuario_gana)
  
  usuario = input("piedra, papel o tijera => ")
  usuario = usuario.lower()
  rounds += 1
  if not usuario in opciones:
    print("No es valido")
    continue
  computadora = random.choice(opciones)
  
  print("opcion de usuario => ", usuario)
  print("opcion de computadora => ", computadora)
  
  # juego de piedra, papel o tijera
  if usuario == computadora:
    print("Empate")
  elif usuario == "piedra":
    if computadora == "tijera":
      print("piedra gana a tijera")
      print("Usuario gana")
      usuario_gana +=1
    else:
      print("papel gana a piedra")
      print("Computadora gana")
      computadora_gana +=1
  elif usuario == "papel":
    if computadora == "piedra":
      print("papel gana a piedra")
      print("usuario gana")
      usuario_gana +=1
    else:
      print("tijera gana a papel")
      print("computadora gana")
      computadora_gana +=1
  elif usuario == "tijera":
    if computadora == "papel":
      print("tijera le gana a papel")
      print("usuario gana")
      usuario_gana +=1
    else:
      print("piedra gana a tijera")
      print("computadora gana")
      computadora_gana +=1

  if usuario_gana == 3:
    print("Gano el usuario")
    break

  if computadora_gana == 3:
    print("Gano la computadora")
    break
  
