print(type(bool(1)))
print(bool(-1))