estado_civil = True
print(type(estado_civil))
estado_civil = False
print(estado_civil)
print(not True)
print(not False)

estado_civil = not estado_civil 
print(estado_civil)