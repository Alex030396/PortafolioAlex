numeros = (1,2,3,4,5)
cadena = ("Alex","Carlos","Dayana","Alex")
print(numeros)
print(numeros[0])
print(numeros[-1])
print(type(numeros))

print(cadena)
print(type(cadena))

print(cadena.index("Carlos"))
print(cadena.count("Alex"))

lista = list(cadena)
print(lista)
print(type(lista))

lista[3] = "Jose"
print(lista)

tupla = tuple(lista)
print(tupla)

n= ["Alex",4,5,"Alex"]
print(n.count("Alex"))