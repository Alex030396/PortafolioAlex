if True:
  print("Tiene que ejecutarse")

if False:
  print("no tiene que ejecutarse")

mascota = input("¿Cual es tu mascota favorita? ")
if mascota == "perro":
  print("El mejor amigo del hombre")
elif mascota == "gato":
  print("Ellos son los amos")
elif mascota == "gpez":
  print("ten agua a la mano")
else:
  print("No hay mascota")

stock = int(input("Ingrese el stock => "))
if stock >= 200 and stock <= 2000:
  print("Stock completo")
else:
  print("Stock incompleto")