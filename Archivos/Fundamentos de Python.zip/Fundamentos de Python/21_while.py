'''
while True:
  print("Ejecutame")

contador = 0

while contador < 10:
  contador += 1
  print(contador)


contador = 0

while contador < 20:
  contador += 1
  if contador == 15:
    break
  print(contador)
  '''
contador = 0

while contador < 20:
  contador += 1
  if contador < 15:
    continue
  print(contador)

  
respuesta = ""

while respuesta != "salir":
    respuesta = input("Escribe 'salir' para detener el bucle: ")
    print("Tú escribiste:", respuesta)
