texto = "Ella sabe programar en python"
print("javascript" in texto)
print("python" in texto)

if "JS" in texto:
  print("Correcto")
else:
  print("Incorrecto")

tamaño = "alex"
print(len(tamaño))

print(texto.upper())
print(texto.lower())
print(texto.count("a"))
print(texto.swapcase())
print(texto.startswith("Ella"))
print(texto.endswith("non"))
print(texto.replace("Ella", "El"))

texto2 = "como ser el mejor"
print(texto2.capitalize())
print(texto2.title())
print(texto2.isdigit())
print("1555".isdigit())
