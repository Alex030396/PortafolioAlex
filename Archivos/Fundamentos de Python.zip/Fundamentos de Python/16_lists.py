numeros = [1,2,3,4,5]
print(numeros)
print(type(numeros))

tareas = ["lavar los platos","jugar videojuegos"]
print(tareas)

tipos = [1, True, "Alex"]
print(tipos)

print(numeros[0])
print(tareas[0])

tareas[0] = "Barrer el piso"
print(tareas)

print(numeros[0:2])
print("Alex" in tipos)