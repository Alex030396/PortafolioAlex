# >
print(7 > 3)
print(3 > 7)
print(7 > 7)

# <  
print(5 < 6)
print(6 < 5)
print(5 < 5)

# >=
print(2 >= 1)
print(2 >= 3)
print(2 >= 2)

# <=
print(2 <= 1)
print(2 <= 3)
print(2 <= 2)

# ==
print(3 == 3)
print(3 == 2)

# !=
print(8 != 8)
print(8 != 9)

print("Manzana" == 'Manzana')
print("Manzana" == 'manzana')

edad = 18
print(edad >= 18)
