lives = 3
print(type(lives))

edad = 28  
presupuesto = 100
temperatura = 12.12
print(type(temperatura))

lives = 2
print(lives)

lives = 1
print(lives)

lives = 12+ 15
print(lives)

lives = lives - 1
print(lives)

lives -= 1
print(lives)

lives -= 5
print(lives)

lives += 5
print(lives)

numero = 4500000000000000000000000000.1
print(numero)

numero_a = 0.0000000000000000001
print(numero_a)