lista = [1,-1,2,-2,3,-3,4,-4]
lista1 = []

for elemento in lista:
  if elemento > 0:
    lista1.append(elemento)

print(lista1)

a = 'alex jose'
a = a.replace('alex', 'jose')
print(a)

b = [1,2,5,7,9,4]
print(b[3])

c = 9
if c >= 10:
  print('mayor')
else:
  print('menor')

print((8/2)+4*8)
print(4!=10)

po = 0

'''while po < 8.85:
  po = po + 0.05
  print('poblacion')

print('pas')'''

le = [2,3,5,7,11,13,17,19,23,29,31,37,41]
a = le[4:11:1]
print(a)