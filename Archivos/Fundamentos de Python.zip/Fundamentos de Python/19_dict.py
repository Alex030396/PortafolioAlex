diccionario = {}
print(type(diccionario))

diccionario = {
  "laptop": "Hp",
  "Lentes": "fotocromatico",
  "gimnasio": "smarfit",
  "sueldo": 3000
}

print(diccionario)
print(len(diccionario))
print(diccionario["sueldo"])
print(diccionario["Lentes"])
print(diccionario.get("edad"))

print("laptop" in diccionario)
print("nombre" in diccionario)