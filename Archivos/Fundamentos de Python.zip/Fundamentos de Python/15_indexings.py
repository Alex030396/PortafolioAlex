texto = "Yo soy un programador en python"
print(texto[0])
print(texto[1])
tamaño= len(texto)
print(tamaño)
print(texto[tamaño -1])
print(texto[-1])

#slicing

print(texto[0:3])
print(texto[25:31])
print(texto[:3])
print(texto[3:-1])
print(texto[3:])
print(texto[:])
print(texto[25:31:2])
print(texto[::2])