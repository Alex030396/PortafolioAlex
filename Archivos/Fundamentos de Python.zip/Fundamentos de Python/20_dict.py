persona = {
  'nombre': 'Alex',
  'apellido': 'Briceño',
  'programas': ['python','javascript'],
  'edad': 28
}
print(persona)
persona['nombre'] = 'Jose'
persona['edad'] += 5
persona['programas'].append('CSS')
print(persona)
del persona['apellido']
persona.pop('edad')
print(persona)

print(persona.items())
print(persona.keys())
print(persona.values())
