# and
print("AND")
print("True AND True => ", True and True)
print("True AND False => ", True and False)
print("False AND False => ", False and False)

print(10 > 5 and 2 < 5) 
print(10 > 5 and 2 > 5)

stock = input("Ingrese el numero de stock => ")
stock = int(stock)
print(stock >= 100 and stock <= 1000)

# or
print("OR")
print("True AND True => ", True or True)
print("True AND False => ", True or False)
print("False AND False => ", False or False)

rol = input("Digita el rol => ")
print(rol == "administrador" or rol == "vendedor")