#a = input('Alex')
#print(a)

edad = 25
tipo = 'agua'
print(f'{edad} del niño de las flores {tipo}')

edad = str(edad )
print(type(edad))

edad = 100
if edad == 25:
  print("Buena onda")
elif edad < 25:
  print("Mala onda")
elif edad > 25:
  print("pasado de onda")
