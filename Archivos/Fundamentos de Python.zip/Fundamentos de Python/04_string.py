from re import template


nombre = "Alex"
apellido = "Briceño"
print(nombre)
print(apellido)
full_nombre = nombre + " " + apellido
print(full_nombre)
ingles = "I'm Alex"
print(ingles)
ingles1 = 'She said "Hello"'
print(ingles1)

template = "Hola, mi nombre es " + nombre + " y mi apellido es " + apellido
print(template)

template = "Hola, mi nombre es {} y mi apellido es {}".format(nombre, apellido)
print(template)

template = f"Hola mi nombre es {nombre} y mi apellido es {apellido}"
print(template)