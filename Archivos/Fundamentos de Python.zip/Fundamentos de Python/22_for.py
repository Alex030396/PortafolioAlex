'''
for elemento in range(20):
  print(elemento)

for elemento in range(1,20):
  print(elemento)
'''
lista = [45,87,65,24,15,35,16]
for elemento in lista:
  print(elemento)

tupla = ("Alex","Carlos","Dayana")
for elemento in tupla:
  print(elemento)

persona = {
  'nombre': 'Alex',
  'apellido': 'Briceño',
  'edad': 28
}
for key in persona:
  print(key, '=>', persona[key])

for key, valor in persona.items():
  print(key, '=>', valor)

personas = [
  {
    'nombre':'alex',
    'edad':28
  },
  {
    'dia':3,
    'nombre':'marzo'
  },
  {
    'profesion':'tsu',
    'nombre':'UNEXPO'
  }]

for all in personas:
  print(all)

for all in personas:
  print('nombre =>', all['nombre'])


lista = [2,4,6,8,10,12,14,16,18,20]

for i in lista:
  lista = i ** 2
  print(i)  