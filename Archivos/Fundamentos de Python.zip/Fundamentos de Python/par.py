numero = int(input("El numero es par o impar = "))

if numero % 2 == 0:
  print("Par")
else:
  print("Impar")


print(18 % 2)