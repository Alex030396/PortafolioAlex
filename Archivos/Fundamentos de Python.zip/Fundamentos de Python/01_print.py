print("Hola esto es python 01 print")
print("Hola soy Alex y tengo 28 años")
print(10+9)
print(10-5)
print(5*2)
print(8/2)
## El comentario legendario.

"""
Para hacer un escrito largo.
Que pueda volver a utilizar y ver
Para saber que estoy haciendo. 
Porque soy el mejor programador de Python.
"""